#!/bin/bash

set -e  # Stop jika ada error

# 🎨 Warna
GREEN='\e[32m'
RED='\e[31m'
YELLOW='\e[33m'
RESET='\e[0m'
echo -e "${GREEN}[*] Bersiap menginstall elysium optimize V1"
sleep 2
echo -e "${YELLOW}[*] Memasukkan panel ke mode maintenance...${RESET}"
php artisan down
sleep 1

echo -e "${YELLOW}[*] Menjalankan migrasi dan seeding database...${RESET}"
php artisan migrate --seed --force
php artisan queue:restart
sleep 1

echo -e "${YELLOW}[*] Menginstall dependensi Node.js...${RESET}"
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg
sudo mkdir -p /etc/apt/keyrings

curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key \
  | sudo gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg

echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_16.x nodistro main" \
  | sudo tee /etc/apt/sources.list.d/nodesource.list

sudo apt-get update
sudo apt-get install -y nodejs

echo -e "${GREEN}[✓] Node.js terinstal${RESET}"
sleep 1

echo -e "${YELLOW}[*] Menginstall dependensi frontend...${RESET}"
cd /var/www/pterodactyl
yarn install --network-timeout 600000
sleep 1

echo -e "${YELLOW}[*] Membangun ulang frontend panel (tema)...${RESET}"
NODE_OPTIONS=--openssl-legacy-provider yarn build:production
sleep 1

echo -e "${YELLOW}[*] Membersihkan cache Laravel...${RESET}"
php artisan migrate --seed --force
php artisan queue:restart
php artisan view:clear
php artisan config:clear
php artisan optimize
php artisan queue:restart
sleep 1

echo -e "${GREEN}[✓] Panel berhasil dioptimalkan dan dibangun ulang${RESET}"
php artisan up
echo -e "${GREEN}[✓] Panel kembali online. Tema seharusnya sudah aktif!${RESET}"
