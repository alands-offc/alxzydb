import React, { useEffect, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faHdd,
  faMemory,
  faMicrochip,
  faBox,
} from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import { Server } from "@/api/server/getServer";
import getServerResourceUsage, {
  ServerStats,
  ServerPowerState,
} from "@/api/server/getServerResourceUsage";
import { bytesToString, mbToBytes } from "@/lib/formatters";
import tw from "twin.macro";
import styled from "styled-components/macro";
import { Button } from "@/components/elements/button";
import CopyOnClick from "@/components/elements/CopyOnClick";
import { getElysiumData } from "@/components/elements/elysium/getElysiumData";

type Timer = ReturnType<typeof setInterval>;

export default ({ server }: { server: Server }) => {
  const server_background = JSON.parse(getElysiumData("--server-background"));
  const [stats, setStats] = useState<ServerStats | null>(null);
  const [status, setStatus] = useState<ServerPowerState | null>(null);
  const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
  const [isSuspended, setIsSuspended] = useState(server.status === "suspended");

  const getStats = () =>
    getServerResourceUsage(server.uuid)
      .then((data) => {
        setStats(data);
        setStatus(data.status);
      })
      .catch((error) => console.error(error));

  useEffect(() => {
    if (isSuspended) return;
    getStats();
    interval.current = setInterval(() => getStats(), 30000);
    return () => clearInterval(interval.current);
  }, []);

  const diskLimit =
    server.limits.disk !== 0
      ? bytesToString(mbToBytes(server.limits.disk))
      : "Unlimited";
  const memoryLimit =
    server.limits.memory !== 0
      ? bytesToString(mbToBytes(server.limits.memory))
      : "Unlimited";
  const cpuLimit =
    server.limits.cpu !== 0 ? server.limits.cpu + "%" : "Unlimited";

  const BackgroundDiv = styled.div`
    ${tw`w-full py-6 px-4 rounded-t-xl`}
    background: linear-gradient(to bottom, rgba(0,0,0,0.4), rgba(0,0,0,0.6)),
      url(${server_background});
    background-size: cover;
    background-position: center;
    backdrop-filter: blur(4px);
  `;

  const StatusBadge = styled.span<{ state: string }>`
    ${tw`rounded-full px-3 py-1 text-xs font-bold text-white`}
    ${({ state }) =>
      state === "running"
        ? tw`bg-green-500`
        : state === "offline"
        ? tw`bg-red-500`
        : tw`bg-yellow-500`}
  `;

  const StatCard = ({
    icon,
    label,
    value,
  }: {
    icon: any;
    label: string;
    value: string | number | React.ReactNode;
  }) => (
    <div css={tw`flex flex-col items-start text-neutral-200`}>
      <div css={tw`flex items-center gap-2 mb-1`}>
        <FontAwesomeIcon icon={icon} />
        <span css={tw`text-sm font-semibold uppercase`}>{label}</span>
      </div>
      <span css={tw`text-sm font-medium`}>{value}</span>
    </div>
  );

  return (
    <div css={tw`bg-[#10141c] border border-neutral-700 rounded-xl shadow-md transition-all hover:scale-[1.01] duration-200`}>
      <BackgroundDiv>
        <h2 css={tw`text-xl font-bold text-center text-white mb-1`}>
          {server.name}
        </h2>
        <div css={tw`text-sm text-center text-neutral-300 mb-2`}>
          {server.allocations
            .filter((alloc) => alloc.isDefault)
            .map((allocation) => (
              <CopyOnClick
                key={allocation.ip + allocation.port.toString()}
                text={`${allocation.alias || allocation.ip}:${allocation.port}`}
              >
                <span>
                  {allocation.alias || allocation.ip}:{allocation.port}
                </span>
              </CopyOnClick>
            ))}
        </div>
        <div css={tw`flex justify-center`}>
          <StatusBadge
            state={
              isSuspended
                ? "offline"
                : status === "running"
                ? "running"
                : "offline"
            }
          >
            {isSuspended
              ? "Suspended"
              : status === "running"
              ? "Running"
              : "Offline"}
          </StatusBadge>
        </div>
      </BackgroundDiv>

      <div css={tw`grid grid-cols-2 sm:grid-cols-4 gap-4 p-4`}>
        <StatCard icon={faBox} label="ID" value={server.id} />
        <StatCard
          icon={faMicrochip}
          label="CPU"
          value={
            stats && !isSuspended
              ? `${stats.cpuUsagePercent.toFixed(2)}% / ${cpuLimit}`
              : "-"
          }
        />
        <StatCard
          icon={faMemory}
          label="Memory"
          value={
            stats && !isSuspended
              ? `${bytesToString(stats.memoryUsageInBytes)} / ${memoryLimit}`
              : "-"
          }
        />
        <StatCard
          icon={faHdd}
          label="Disk"
          value={
            stats && !isSuspended
              ? `${bytesToString(stats.diskUsageInBytes)} / ${diskLimit}`
              : "-"
          }
        />
      </div>

      <div css={tw`px-4 pb-4`}>
        <Link to={`/server/${server.id}`}>
          <Button
            css={tw`w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-purple-700 hover:to-blue-700`}
          >
            Manage Server
          </Button>
        </Link>
      </div>
    </div>
  );
};
