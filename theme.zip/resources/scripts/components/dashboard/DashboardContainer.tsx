import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import styled from "styled-components/macro";
import useSWR from "swr";

import { Server } from "@/api/server/getServer";
import getServers from "@/api/getServers";
import { PaginatedResult } from "@/api/http";
import { useStoreState } from "easy-peasy";
import { usePersistedState } from "@/plugins/usePersistedState";
import useFlash from "@/plugins/useFlash";

import PageContentBlock from "@/components/elements/PageContentBlock";
import ContentBox from "@/components/elements/ContentBox";
import Spinner from "@/components/elements/Spinner";
import Switch from "@/components/elements/Switch";
import Pagination from "@/components/elements/Pagination";
import ServerRow from "@/components/dashboard/ServerRow";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLayerGroup } from "@fortawesome/free-solid-svg-icons";

import tw from "twin.macro";

// Styled component dengan style berbeda dari default elysium
const ServerPanelHeader = styled.div`
  ${tw`flex items-center mb-4 pb-2 border-b border-neutral-700`}
`;

const ServerPanelTitle = styled.h1`
  ${tw`text-xl md:text-2xl text-white font-bold ml-3`}
`;

const AdminToggle = styled.div`
  ${tw`mb-4 flex justify-end items-center`}
`;

const ServerGrid = styled.div`
  ${tw`grid gap-4`}
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
`;

const Dashboard = () => {
  const { search } = useLocation();
  const defaultPage = Number(new URLSearchParams(search).get("page") || "1");
  const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);

  const { clearFlashes, clearAndAddHttpError } = useFlash();
  const uuid = useStoreState((state) => state.user.data!.uuid);
  const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);

  const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(
    `${uuid}:show_all_servers`,
    false
  );

  const { data: servers, error } = useSWR<PaginatedResult<Server>>(
    ["/api/client/servers", showOnlyAdmin && rootAdmin, page],
    () => getServers({ page, type: showOnlyAdmin && rootAdmin ? "admin" : undefined })
  );

  useEffect(() => {
    if (servers && servers.pagination.currentPage > 1 && servers.items.length === 0) {
      setPage(1);
    }
  }, [servers]);

  useEffect(() => {
    window.history.replaceState(null, document.title, page <= 1 ? "/" : `?page=${page}`);
  }, [page]);

  useEffect(() => {
    if (error) clearAndAddHttpError({ key: "dashboard", error });
    else clearFlashes("dashboard");
  }, [error]);

  return (
    <PageContentBlock title="Dashboard" showFlashKey="dashboard">
      <ContentBox css={tw`shadow-lg rounded-lg bg-neutral-900 p-6`}>
        {/* Header Section */}
        <ServerPanelHeader>
          <FontAwesomeIcon icon={faLayerGroup} size="lg" />
          <ServerPanelTitle>My Server List</ServerPanelTitle>
        </ServerPanelHeader>

        {/* Admin Toggle */}
        {rootAdmin && (
          <AdminToggle>
            <span css={tw`text-sm text-neutral-400 mr-2`}>
              {showOnlyAdmin ? "Viewing all servers" : "Viewing owned servers"}
            </span>
            <Switch
              name="show_all_servers"
              defaultChecked={showOnlyAdmin}
              onChange={() => setShowOnlyAdmin((s) => !s)}
            />
          </AdminToggle>
        )}

        {/* Server List */}
        {!servers ? (
          <Spinner centered size="large" />
        ) : (
          <Pagination data={servers} onPageSelect={setPage}>
            {({ items }) =>
              items.length > 0 ? (
                <ServerGrid>
                  {items.map((server) => (
                    <div
                      key={server.uuid}
                      css={tw`bg-neutral-800 rounded-md shadow-md hover:shadow-lg transition duration-300`}
                    >
                      <ServerRow server={server} />
                    </div>
                  ))}
                </ServerGrid>
              ) : (
                <p css={tw`text-sm text-neutral-400 text-center mt-6`}>
                  {showOnlyAdmin
                    ? "No other servers available to display."
                    : "You have no servers at the moment."}
                </p>
              )
            }
          </Pagination>
        )}
      </ContentBox>
    </PageContentBlock>
  );
};

export default Dashboard;
