import React, { useEffect, useRef, useState } from "react";
import { Link, RouteComponentProps } from "react-router-dom";
import login from "@/api/auth/login";
import LoginFormContainer from "@/components/auth/LoginFormContainer";
import { useStoreState } from "easy-peasy";
import { Formik, FormikHelpers } from "formik";
import { object, string } from "yup";
import Field from "@/components/elements/Field";
import tw from "twin.macro";
import { Button } from "@/components/elements/button";
import Reaptcha from "reaptcha";
import useFlash from "@/plugins/useFlash";

interface Values {
  username: string;
  password: string;
}

const LoginContainer = ({ history }: RouteComponentProps) => {
  const recaptchaRef = useRef<Reaptcha>(null);
  const [token, setToken] = useState("");

  const { clearFlashes, clearAndAddHttpError } = useFlash();
  const { enabled: recaptchaEnabled, siteKey } = useStoreState(
    (state) => state.settings.data!.recaptcha
  );

  useEffect(() => {
    clearFlashes();
  }, []);

  const onSubmit = (
    values: Values,
    { setSubmitting }: FormikHelpers<Values>
  ) => {
    clearFlashes();

    if (recaptchaEnabled && !token) {
      recaptchaRef.current?.execute().catch((error) => {
        console.error(error);
        setSubmitting(false);
        clearAndAddHttpError({ error });
      });
      return;
    }

    login({ ...values, recaptchaData: token })
      .then((response) => {
        if (response.complete) {
          window.location.href = response.intended || "/";
        } else {
          history.replace("/auth/login/checkpoint", {
            token: response.confirmationToken,
          });
        }
      })
      .catch((error) => {
        console.error(error);
        setToken("");
        recaptchaRef.current?.reset();
        setSubmitting(false);
        clearAndAddHttpError({ error });
      });
  };

  return (
    <div css={tw`absolute inset-0 bg-elysium-color1 flex items-center justify-center`}>
      <div css={tw`w-full max-w-md px-6`}>
        <Formik
          onSubmit={onSubmit}
          initialValues={{ username: "", password: "" }}
          validationSchema={object().shape({
            username: string().required("Username or email is required."),
            password: string().required("Password is required."),
          })}
        >
          {({ isSubmitting, submitForm, setSubmitting }) => (
            <LoginFormContainer title="Welcome Back 👋">
              <Field
                type="text"
                name="username"
                label="Username or Email"
                disabled={isSubmitting}
              />

              <div css={tw`mt-6`}>
                <Field
                  type="password"
                  name="password"
                  label="Password"
                  disabled={isSubmitting}
                />
              </div>

              {recaptchaEnabled && (
                <Reaptcha
                  ref={recaptchaRef}
                  size="invisible"
                  sitekey={siteKey || "_invalid_key"}
                  onVerify={(response) => {
                    setToken(response);
                    submitForm();
                  }}
                  onExpire={() => {
                    setSubmitting(false);
                    setToken("");
                  }}
                />
              )}

              <div css={tw`mt-6`}>
                <Button
                  css={tw`w-full bg-elysium-green hover:bg-green-500 transition duration-200`}
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Logging in..." : "Login"}
                </Button>

                <Link to="/auth/password">
                  <Button.Danger css={tw`w-full mt-2`}>
                    Forgot Password
                  </Button.Danger>
                </Link>
              </div>
            </LoginFormContainer>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default LoginContainer;
