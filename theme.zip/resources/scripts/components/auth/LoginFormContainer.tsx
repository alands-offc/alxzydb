import React, { forwardRef } from "react";
import { Form } from "formik";
import styled from "styled-components/macro";
import { breakpoint } from "@/theme";
import FlashMessageRender from "@/components/FlashMessageRender";
import tw from "twin.macro";
import { getElysiumData } from "@/components/elements/elysium/getElysiumData";

type Props = React.DetailedHTMLProps<
  React.FormHTMLAttributes<HTMLFormElement>,
  HTMLFormElement
> & {
  title?: string;
};

const Container = styled.div`
  ${breakpoint("sm")`${tw`mx-auto`}`};
  ${breakpoint("md")`${tw`p-10`}`};
  ${breakpoint("xl")`${tw`w-auto`}`};
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => (
  <div css={tw`flex justify-center flex-col`}>
    <Container>
      <FlashMessageRender css={tw`mb-2 px-1`} />

      <div
        css={tw`flex flex-col md:flex-row items-center bg-elysium-color2 rounded-2xl shadow-2xl md:py-16 md:px-12 py-12 px-6 md:mb-8 mb-4 transition-all duration-300 ease-in-out`}
      >
        <img
          css={tw`w-32 md:w-48 mb-6 md:mb-0 md:mr-10 transition-transform duration-300 hover:scale-105`}
          src={JSON.parse(getElysiumData("--logo"))}
          alt="Brand Logo"
        />

        <div css={tw`flex flex-col items-center md:items-start`}>
          {title && (
            <h2 css={tw`text-lg text-neutral-100 font-semibold py-4`}>
              {title}
            </h2>
          )}
          <div css={tw`w-72 md:w-80`}>
            <Form css={tw`flex flex-col gap-4`} {...props} ref={ref}>
              {props.children}
            </Form>
          </div>
        </div>
      </div>

      <p css={tw`text-center text-neutral-100 text-xs mt-6`}>
        &copy; {JSON.parse(getElysiumData("--copyright-start-year"))} -{" "}
        {new Date().getFullYear()}{" "}
        <a
          href={JSON.parse(getElysiumData("--copyright-link"))}
          target="_blank"
          rel="noopener noreferrer"
          css={tw`text-neutral-200 hover:text-elysium-green transition duration-200`}
        >
          {JSON.parse(getElysiumData("--copyright-by"))}
        </a>
      </p>
    </Container>
  </div>
));
