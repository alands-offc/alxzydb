import puppeteer from "puppeteer";
import express from "express";
import cors from "cors";
import fs from "fs";

const port = process.env.PORT || 3000;

if (!fs.existsSync("./tmp")) {
  fs.mkdirSync("./tmp");
}

const app = express();
app.use(cors());

let browser;

const initBrowser = async () => {
  browser = await puppeteer.launch();
};
initBrowser();

app.get("/", (req, res) => {
  res.json({
    status: true,
    creator: "alxzy",
    donate: "https://saweria.co/alxzydev",
    get: [{
      ssweb: "/api/v2/ssweb?url=url&width=&height="
    }]
  });
});

app.get("/api/v2/ssweb", async (req, res) => {
  const { url, width, height } = req.query;
  if (!url) return res.status(400).json({ status: false, message: "url required" });

  try {
    const filename = url.replace("https://", "").split("/")[0] + Date.now(); 
    const _filename = `./tmp/${filename}.png`;

    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'networkidle2' });
    await page.setViewport({
      width: parseInt(width) || 1280,
      height: parseInt(height) || 720,
    });
    await page.screenshot({ path: _filename });
    await page.close();

    res.setHeader("Content-Type", "image/png");
    res.sendFile(_filename, { root: '.' });
  } catch (err) {
    res.status(500).json({ status: false, message: "Failed to capture screenshot", error: err.message });
  }
});

app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
