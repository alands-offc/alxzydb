import axios from "axios";
import * as cheerio from "cheerio";

/**
 * Download dari Spotify dan dapatkan semua link download
 * @param {string} spotifyUrl - link spotify track (contoh: https://open.spotify.com/track/4zRZAmBQP8vhNPf9i9opXt)
 */
async function getSpotifyDownloadLinks(spotifyUrl) {
  try {
    // Step 1: POST ke /action
    const actionRes = await axios.post("https://spotidown.app/action", {
      url: spotifyUrl,
    });

    // Step 2: POST ke /action/track dengan data yg didapat
    const trackRes = await axios.post("https://spotidown.app/action/track", {
      url: spotifyUrl,
    });

    // Data HTML ada di field "data"
    const html = trackRes.data?.data;
    if (!html) throw new Error("Tidak ada data dari spotidown");

    // Step 3: Parse HTML pakai cheerio
    const $ = cheerio.load(html);

    let links = [];
    $("a").each((_, el) => {
      const href = $(el).attr("href");
      const text = $(el).text().trim();
      if (href && href.startsWith("http")) {
        links.push({ text, href });
      }
    });

    return links;
  } catch (err) {
    console.error("Error getSpotifyDownloadLinks:", err.message);
    return [];
  }
}

// contoh pemakaian
(async () => {
  const links = await getSpotifyDownloadLinks(
    "https://open.spotify.com/track/4zRZAmBQP8vhNPf9i9opXt"
  );
  console.log(links);
})();
