const {
  makeWASocket,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  Browsers,
  delay,
  jidNormalizedUser
} = require("baileys");
const pino = require("pino");
const fs = require("fs");
const readline = require("readline");
const { Boom } = require("@hapi/boom");
const chalk = require("chalk");
const store = require("./lib/store");
const { pesan, kirim } = require("./pesan.js");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

const logger = pino({ timestamp: () => `,"time":"${new Date().toJSON()}"` }, pino.destination("./bken.log"));
logger.level = "debug";

async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState("./sessions");
  const { version, islatest } = await fetchLatestBaileysVersion();
  console.log(`Versi Baileys: ${version.join(".")}, terbaru: ${islatest}`);

  let bken = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: "silent", stream: "store" })),
    },
    browser: Browsers.ubuntu("Chrome"),
    shouldSyncHistoryMessage: () => true,
    syncFullHistory: true,
    generateHighQualityLinkPreview: true,
  });
  if (!bken.authState.creds.registered) {
    console.log(chalk.magenta("——————————————————"));
    const number = await question(chalk.blue("Input Whatsapp Number: "));
    const code = await bken.requestPairingCode(number.trim());
    console.log(chalk.green(`Your code: ${code}`));
    console.log(chalk.magenta("——————————————————"));
  }
  bken = await kirim(bken)
  // Event handler
  bken.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
      if (connection === "close") {
    const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;

    switch (reason) {
      case DisconnectReason.loggedOut:
        console.log("device logout, logout...");
        process.exit(1);
        break;
      case DisconnectReason.restartRequired:
      case DisconnectReason.timedOut:
      await connect()
        break;
    }
  } else if (connection === "open") {
    store.bind(bken);
    console.log("Berhasil tersambung, connected");
    bken.setupJpm(bken)
    }
  });

  bken.ev.on("creds.update", saveCreds);
  bken.isPublic = true;
  bken.isJpmActive = true;
  bken.jpmIntervalMenit = 250;
  bken.jpmInterval;
  bken.nextJpmTimestamp = 0;
  bken.startTime = Date.now();
  bken.ev.on("messages.upsert", async (updates) => {
    let messages = updates.messages[0];
    if (!messages.message) return;
    if (messages.key.id.startsWith("BAE5") || (messages.key.id.startsWith("3EB0") && messages.key.id.length === 22)) {
      return;
    }
    const m = await pesan(bken, messages);
    if (!(m.sender === jidNormalizedUser(bken.user.id)) && !bken.isPublic) return;
    await require("./lib/log.js")(bken, m);
    await require("./bken.js")(bken, m);
    await bken.sleep(3000)
  });
}

connect();