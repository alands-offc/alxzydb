const axios = require("axios");
const createConfig = require("./config");

module.exports = async function (bken, m) {
  let config = await createConfig();
  let args = m.args;
  let text = args.join(" ");
  let sender = m.sender;
  const isOwner = owners.includes(sender.split('@')[0]);
  if (m.command && m.prefix) {
    switch (m.command.toLowerCase()) {
    case "menu": {
  let txt = 
`╭━━━〔 ⚡ *BKEN BOT MENU* ⚡ 〕━━━╮

🛠 *Fitur Utama*:
  • .p / .payment  → Cek metode pembayaran
  • .list          → List harga VPN premium
  • .sidompul      → Cek kuota nomor HP
  • .owner         → Kontak Owner Bot

💡 Tips:
  Ketik perintah sesuai di atas, 
  gunakan prefix *${m.prefix}*.

╰━━━━━━━━━━━━━━━━━━━━━━━━╯
🔥 BKEN VPN – Cepat, Stabil, Terpercaya! 🔥`;

  bken.sendMessage(
    m.chat, 
    { 
      text: txt, 
    }, 
    contextInfo: config.external,
    { quoted: m }
  );
  break;
}
case 'self':
                if (!isOwner) return; bken.isPublic = false;
                bken.sendMessage(m.chat, { text: '✅ Bot sekarang dalam mode Self.' }, { quoted: m }); break;
            case 'public':
                if (!isOwner) return; bken.isPublic = true;
                bken.sendMessage(m.chat, { text: '✅ Bot sekarang dalam mode Public.' }, { quoted: m }); break;
            case 'jpm':
                if (!isOwner) return;
                if (args[0] === 'on') { bken.isJpmActive = true; bken.setupJpm(bken); bken.sendMessage(m.chat, { text: '✅ JPM diaktifkan.' }, { quoted: m }); } 
                else if (args[0] === 'off') { bken.isJpmActive = false; if (bken.jpmInterval) clearInterval(bken.jpmInterval); bken.sendMessage(m.chat, { text: '❌ JPM dinonaktifkan.' }, { quoted: m }); }
                else { bken.sendMessage(m.chat, { text: `Gunakan: *${prefix}jpm on* atau *${prefix}jpm off*` }, { quoted: m }); }
                break;
case "cekjpm": {
  if (!bken.isJpmActive) {
    return bken.sendMessage(
      m.chat, 
      { text: "❌ Fitur JPM sedang *tidak aktif*.", contextInfo: config.external }, 
      { quoted: m }
    );
  }

  const timeLeft = bken.nextJpmTimestamp - Date.now();
  const minutes = Math.floor(timeLeft / 60000);
  const seconds = ((timeLeft % 60000) / 1000).toFixed(0);

  bken.sendMessage(
    m.chat, 
    { text: `⏳ Promosi berikutnya akan dikirim dalam:\n\n*${minutes} menit ${seconds} detik*`, contextInfo: config.external }, 
    { quoted: m }
  );
  break;
}

case "ubhtimejpm": {
  if (!isOwner) return;
  const newTime = parseInt(args[0]);

  if (isNaN(newTime) || newTime < 5) {
    return bken.sendMessage(
      m.chat, 
      { text: "⚠️ Gunakan format:\n.ubhtimejpm <menit>\n\nContoh: *.ubhtimejpm 120*\n(Minimal 5 menit)", contextInfo: config.external }, 
      { quoted: m }
    );
  }

  bken.jpmIntervalMenit = newTime;
  bken.setupJpm(bken); 

  bken.sendMessage(
    m.chat, 
    { text: `✅ Interval JPM berhasil diubah menjadi setiap *${bken.jpmIntervalMenit} menit*.`, contextInfo: config.external }, 
    { quoted: m }
  );
  break;
}

case "bc": {
  if (!isOwner) return;
  const quotedMsg = m.quoted? m.quoted : m
  if (!quotedMsg) {
    return bken.sendMessage(
      m.chat, 
      { text: "⚠️ Reply pesan yang ingin di-*broadcast* dengan perintah *.bc*", contextInfo: config.external }, 
      { quoted: m }
    );
  }

  const groups = await bken.groupFetchAllParticipating();
  const groupList = Object.values(groups);

  if (groupList.length === 0) {
    return bken.sendMessage(
      m.chat, 
      { text: "❌ Bot tidak ada di grup manapun.", contextInfo: config.external }, 
      { quoted: m }
    );
  }

  await bken.sendMessage(
    m.chat, 
    { text: `📢 Memulai *broadcast* ke ${groupList.length} grup...`, contextInfo: config.external }, 
    { quoted: m }
  );

  let successCount = 0, failCount = 0;
  for (const group of groupList) {
    try {
      await bken.forwardMessage(group.id, quotedMsg);
      successCount++;
    } catch {
      failCount++;
    }
    await sleep(Math.floor(Math.random() * 4000) + 2000);
  }

  await bken.sendMessage(
    m.chat, 
    { text: `✅ Broadcast selesai.\n\n*Berhasil:* ${successCount} grup\n*Gagal:* ${failCount} grup`, contextInfo: config.external }, 
    { quoted: m }
  );
  break;
}

      case "p":
      case "payment": {
        bken.sendMessage(m.chat, {
          image: { url: config.media.thumbnail },
          caption: 
`𖣘 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𖣘
━━━━━━━━━━━━━━━━━━
> 𝘿𝘼𝙉𝘼    : 083895520512
> 𝙊𝙑𝙊       : 083895520512
> 𝙂𝙊𝙋𝘼𝙔  : 08388856799
━━━━━━━━━━━━━━━━━━
📌 *Bukti transfer wajib berupa screenshot!*`
        }, { quoted: m });
        break;
      }

      case "list": {
        let txt = 
`•━━━━━━━━━━━━━━━━━•
⚡ 𝗕𝗞𝗘𝗡 𝗩𝗣𝗡 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 ⚡
•━━━━━━━━━━━━━━━━━•

🔰 SSH WS & OVPN
🔰 V2RAY VMESS
🔰 XRAY VLESS
🔰 TROJAN WS
🔰 TROJAN

━━━━━━━━━━━━━━━━━━
🌐 *SERVER SINGAPORE*

📦 VIP PACKAGE
🇸🇬 15 HARI : 5.000
🇸🇬 30 HARI : 8.000
🇸🇬 60 HARI : 16.000
> 1 IP

📦 VVIP PACKAGE
🇸🇬 15 HARI : 7.000
🇸🇬 30 HARI : 10.000
🇸🇬 60 HARI : 20.000
> 2 IP

━━━━━━━━━━━━━━━━━━
✨ *KELEBIHAN MEMBELI VPN PREMIUM*:
• Trial tersedia ✓
• Server stabil & minim gangguan ✓
• Support VC & Telepon ✓
• Support Game & Streaming ✓
• Speed stabil & anti lag ✓
• Full Garansi ✓
• Bisa request config ✓
• 100% Aman & Terpercaya ✓

━━━━━━━━━━━━━━━━━━
📞 *ORDER / TRIAL*:
wa.me/6281269074996
wa.me/6283895520512

━━━━━━━━━━━━━━━━━━
💰 *PEMBAYARAN*:
➡️ DANA | GOPAY | SHOPEEPAY
➡️ QRIS | PULSA

━━━━━━━━━━━━━━━━━━
📢 *Gabung Grup WhatsApp*:
https://chat.whatsapp.com/JIwVG3Z2Q4K9JWOaewuOUg
https://chat.whatsapp.com/GrkJV1nkkrjCgElzIE0x6h

📢 *Testimoni*:
https://whatsapp.com/channel/0029VaoNYcb3mFY6nJ9y1w2E

•━━━━━━━━━━━━━━━━━•
🔥 𝗕𝗞𝗘𝗡 𝗩𝗣𝗡 – Koneksi Cepat & Stabil! 🔥
•━━━━━━━━━━━━━━━━━•`;
        
        bken.sendMessage(m.chat, { text: txt }, { quoted: m });
        break;
      }

      case "cek":
      case "sidompul": {
        if (!text) {
          return bken.sendMessage(m.chat, { 
            text: '❌ Masukkan nomor HP.\nContoh: .sidompul 081234567890' 
          }, { quoted: m });
        }

        const nomor = text.trim();
        if (!nomor.match(/^(08|628)\d{8,}$/)) {
          return bken.sendMessage(m.chat, { 
            text: "❌ Nomor tidak valid. Harus diawali dengan 08 atau 628 (min. 10 digit)." 
          }, { quoted: m });
        }
        
        await bken.sendMessage(m.chat, { text: `🔍 Memeriksa kuota nomor: *${nomor}* ...`}, { quoted: m });

        const url = "https://sidompul.hijaubiru.my.id/backend.php";
        const headers = { "Content-Type": "application/json" };
        const payload = { action: "check_package", device_id: "fake", number: nomor };

        try {
          const res = await axios.post(url, payload, { headers });
          const result = res.data;

          if (!result.success) {
            return bken.sendMessage(m.chat, { text: "❌ Gagal mengambil data. Nomor tidak ditemukan / API error."}, { quoted: m });
          }

          const data = result.data;
          const quotas = data.quotas.value;
          let t = 
`📱 *INFO NOMOR*
━━━━━━━━━━━━━━━━━━
• *MSISDN* : ${nomor}
• *Tipe Kartu* : ${data.prefix.value}
• *Status 4G* : ${data.status_4g.value}
• *Dukcapil* : ${data.dukcapil.value}
• *Umur Kartu* : ${data.active_card.value}
• *Masa Aktif* : ${data.active_period.value}
• *Masa Tenggang* : ${data.grace_period.value}

📦 *KUOTA TERSEDIA*
━━━━━━━━━━━━━━━━━━`;

          if (quotas && quotas.length > 0) {
            for (const paket of quotas) {
              t += `\n🔸 *${paket.name}*\n📆 Hingga: ${paket.date_end}\n`;
              for (const detail of paket.detail_quota) {
                const persen = detail.percent || 0;
                const icon = persen > 0 ? "✅" : "❌";
                t += `  └─ ${icon} *${detail.name}* → ${detail.remaining_text} / ${detail.total_text} (${persen}%)\n`;
              }
            }
          } else {
            t += `\n❌ Tidak ada paket kuota aktif.`;
          }

          await bken.sendMessage(m.chat, { text: t }, { quoted: m });

        } catch (e) {
          console.error(e);
          bken.sendMessage(m.chat, { text: `❌ Terjadi kesalahan:\n${e.message}`}, { quoted: m });
        }
        break;
      }

      case "owner": {
        await bken.sendMessage(m.chat, { text: "📞 *Kontak Owner Bot*:" }, { quoted: m });
        for (let i = 0; i < config.owner.length; i++) {
          const vcard = 
`BEGIN:VCARD
VERSION:3.0
FN:Owner Bot ${i + 1}
ORG:BKEN BOT;
TEL;type=CELL;type=VOICE;waid=${config.owner[i]}:${config.owner[i]}
END:VCARD`;
          await bken.sendMessage(m.chat, { contacts: { displayName: `Owner Bot ${i + 1}`, contacts: [{ vcard }] } });
          await sleep(500);
        }
        break;
      }

    } // end switch
  } // end if
  return
};
