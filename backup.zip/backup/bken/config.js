const fs = require("fs/promises");
const path = require("path");

async function loadJSON(filePath, fallback = []) {
  try {
    const data = await fs.readFile(filePath, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    console.error(`[CONFIG] Gagal memuat file JSON: ${path.basename(filePath)}`, error);
    return fallback;
  }
}

async function createConfig() {
  const PESAN_PROMOSI = `
•━━━━━━━━━━━━━━━━━━━━•
🔰 *READY XL UNLI VIDIO* •━━━━━━━━━━━━━━━━━━━━•
https://chat.whatsapp.com/JIwVG3Z2Q4K9JWOaewuOUg

𝙉𝙞𝙠𝙢𝙖𝙩𝙞 𝙞𝙣𝙩𝙚𝙧𝙣𝙚𝙩𝙖𝙣 𝙏𝘼𝙉𝙋𝘼 𝘽𝘼𝙏𝘼𝙎 𝙨𝙚𝙗𝙪𝙡𝙖𝙣 𝙥𝙚𝙣𝙪𝙝 𝙙𝙚𝙣𝙜𝙖𝙣 𝙓𝙇 𝙐𝙉𝙇𝙄 𝙎𝙐𝙋𝙀𝙍 𝙈𝙐𝙍𝘼𝙃!!
━━━━━━━━━━━━━━━━━━━━━
* *𝑯𝑨𝑹𝑮𝑨 𝑲𝑼𝑶𝑻𝑨 𝑪𝑼𝑴𝑨𝑵 37K*
* 𝙼𝙰𝚂𝙰 𝙰𝙺𝚃𝙸𝙵 𝙺𝚄𝙾𝚃𝙰 30 𝙷𝙰𝚁𝙸.
* 𝙼𝙴𝙽𝙰𝙼𝙱𝙰𝙷 𝙼𝙰𝚂𝙰 𝙰𝙺𝚃𝙸𝙵 𝙺𝙰𝚁𝚃𝚄.
* 𝙺𝚄𝙾𝚃𝙰 𝙶𝙴𝙳𝙴: 𝙻𝚒𝚖𝚒𝚝 𝙵𝚄𝙿 *±150𝗚𝗕*.
* 𝙲𝙾𝙲𝙾𝙺 𝙿𝙴𝙽𝙶𝙶𝙰𝙽𝚃𝙸 𝚇𝙻 𝚇𝚄𝚃𝚂      
* 𝙿𝙰𝙺𝙴𝚃 𝙺𝙷𝚄𝚂𝚄𝚂 𝙸𝙽𝙹𝙴𝙲𝚃.
🎁 *𝙱𝙾𝙽𝚄𝚂 𝚂𝙿𝙴𝚂𝙸𝙰𝙻:*
       𝙈𝙚𝙣𝙙𝙖𝙥𝙖𝙩𝙠𝙖𝙣 𝙘𝙤𝙣𝙛𝙞𝙜 
       𝙋𝙧𝙚𝙢𝙞𝙪𝙢 1 𝙗𝙪𝙡𝙖𝙣

━━━━━━━━━━━━━━━━━━━━━
📌 𝗠𝗢𝗛𝗢𝗡 𝗗𝗜𝗣𝗘𝗥𝗛𝗔𝗧𝗜𝗞𝗔𝗡
Paket internet ini adalah paket inject. Kebijakan FUP dan layanan dapat berubah sewaktu-waktu oleh operator.  
𝙏𝙞𝙙𝙖𝙠 𝙖𝙙𝙖 𝙜𝙖𝙧𝙖𝙣𝙨𝙞. 𝙈𝙚𝙢𝙗𝙚𝙡𝙞 𝙗𝙚𝙧𝙖𝙧𝙩𝙞 𝙨𝙚𝙩𝙪𝙟𝙪.
━━━━━━━━━━━━━━━━━━━━━
Order via WhatsApp:
📲 wa.me/6281269074996

📢 Testimoni Pelanggan:  
https://whatsapp.com/channel/0029VaoNYcb3mFY6nJ9y1w2E

📢 Gabung Grup WhatsApp:  
https://chat.whatsapp.com/GrkJV1nkkrjCgElzIE0x6h
`;
  const ownerList = await loadJSON(path.join(__dirname, "./database/owner.json"));
  const premiumList = await loadJSON(path.join(__dirname, "./database/premium.json"));

  const thumbnail = "https://files.catbox.moe/kstran.jpg";
  const thumbnail2 = "https://raw.githubusercontent.com/alands-offc/alxzydb/main/1749919242494.jpeg";

  return {
    bot: {
      owner: ["6283899858313", ...ownerList],
      premium: premiumList,
      prefix: ["."],
    },
    text: PESAN_PROMOSI,
    sticker: {
      packname: "Sticker created by",
      author: "Alxzy",
    },
    media: {
      thumbnail: thumbnail,
      thumbnail2: thumbnail2,
    },
    external: {
      thumbnailUrl: thumbnail,
      mimeType: "image/jpeg",
      title: "bken",
      body: "bken",
      mediaType: 1,
      sourceUrl: "https://www.alxzy.xyz",
      renderLargerThumbnail: true,
    },
    regex: {
      tiktok: /(?:https?:\/\/)?(?:www\.)?(?:vm\.|vt\.)?tiktok\.com\/[^\s]+/i,
      instagram: /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:reel|p|tv)\/[^\s]+/i,
      facebook: /(?:https?:\/\/)?(?:www\.)?facebook\.com\/[^\s]+/i,
      youtube: /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)[^\s]+/i,
      pinterest: /(?:https?:\/\/)?(?:www\.)?pinterest\.com\/pin\/[^\s]+/i,
    },
  };
}
module.exports = createConfig
