import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function loadJSON(filePath, fallback = []) {
  try {
    const data = await fs.readFile(filePath, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    console.error(`[CONFIG] Gagal memuat file JSON: ${path.basename(filePath)}`, error);
    return fallback;
  }
}

const ownerList = await loadJSON(path.join(__dirname, "./database/owner.json"));
const premiumList = await loadJSON(path.join(__dirname, "./database/premium.json"));

const thumbnail = "https://raw.githubusercontent.com/alands-offc/alxzydb/main/1749919184266.jpeg";
const thumbnail2 = "https://raw.githubusercontent.com/alands-offc/alxzydb/main/1749919242494.jpeg";

const config = {
  bot: {
    owner: ["6283899858313", ...ownerList],
    premium: premiumList,
    prefix: ["."],
  },
  sticker: {
    packname: "Sticker created by",
    author: "Alxzy",
  },
  api: {
    panelUrl: 'https://sigma.alxzy.xyz',
    apiKey: 'ptla_5EuN4kQc29ybGISEnZ21DXA16c2YhymI6BgQv0d7N1C',
    clientKey: 'ptlc_l7kSWM7uDWHRMVjtuflUApJvj4206fWxtsnhoOCDFzX',
    pterodactyl: {
      defaultEggId: 15,
      defaultLocationId: 1,
      nestId: 5,
    },
  },
  media: {
    thumbnail: thumbnail,
    thumbnail2: thumbnail2,
  },
  external: {
    thumbnailUrl: thumbnail2,
    mimeType: "image/jpeg",
    title: "Akaza - md",
    body: "Akaza - md New era",
    mediaType: 1,
    sourceUrl: "https://www.alxzy.xyz",
    renderLargerThumbnail: true,
  },
  regex: {
    tiktok: /(?:https?:\/\/)?(?:www\.)?(?:vm\.|vt\.)?tiktok\.com\/[^\s]+/i,
    instagram: /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:reel|p|tv)\/[^\s]+/i,
    facebook: /(?:https?:\/\/)?(?:www\.)?facebook\.com\/[^\s]+/i,
    youtube: /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)[^\s]+/i,
    pinterest: /(?:https?:\/\/)?(?:www\.)?pinterest\.com\/pin\/[^\s]+/i,
  },
};

export default config;