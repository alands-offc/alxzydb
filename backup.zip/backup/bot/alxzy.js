import config from "./config.js";
import axios from 'axios';
import { jidNormalizedUser } from "baileys"
import fs from 'fs/promises';
import path from 'path';
import util from "util";
const { owner, premium } = config.bot
const { apiKey, panelUrl, clientKey } = config.api
const { defaultEggId, defaultLocationId, nestId } = config.api.pterodactyl
const headers = {
  'Authorization': `Bearer ${apiKey}`,
  'Content-Type': 'application/json',
  'Accept': 'application/json',
};

const RAM_OPTIONS = {
    "1gb": { ram: 1024, disk: 10240, cpu: 50 },
    "2gb": { ram: 2048, disk: 20480, cpu: 100 },
    "3gb": { ram: 3072, disk: 30720, cpu: 150 },
    "4gb": { ram: 4096, disk: 40960, cpu: 200 },
    "unli": { ram: 0, disk: 0, cpu: 0},
    "admin": { ram: 0, disk: 0, cpu: 0, admin: true},
};

export default async function(m, alxzy) {
  
  let botNumber = jidNormalizedUser(alxzy.user.id);

  let senderNumber = m.sender.replace("@s.whatsapp.net", "");

  let isPremium = premium.includes(senderNumber);
  let own = owner.includes(senderNumber) || owner.includes(botNumber.replace("@s.whatsapp.net", "")) 
  let Ac = owner || isPremium;

  if (!own && isPremium && RAM_OPTIONS["admin"]) {
    delete RAM_OPTIONS["admin"];
}

const premiumFile = path.join('./database/premium.json');
async function ensurePremiumFile() {
    try {
        await fs.access(premiumFile);
    } catch {
        await fs.writeFile(premiumFile, JSON.stringify([], null, 2));
    }
}

  if (m.command && m.prefix) {
  switch (m.command.toLowerCase()) {
    case "menu": {
    let menu = `
👑 *Cpanel by Alxzy* 👑

📌 *Daftar Perintah:*

1️⃣ .cpanel
   ➤ Create Panel

2️⃣ .addprem <nomor/@tag>
   ➤ Menambahkan pengguna ke daftar premium.

3️⃣ .delprem <nomor/@tag>
   ➤ Menghapus pengguna dari daftar premium.

4️⃣ .listprem
   ➤ Menampilkan semua pengguna premium.
.
`;

    m.reply(menu);
    break;
}

    case "cpanel": {
      if (!Ac) return m.reply("kamu tidak memiliki akses")
      try {
        if (m.args.length < 3) {
          return m.reply(`❌ *Perintah Salah!*\n\n*Format:*\n${m.prefix + m.command} <ukuran> <nama> <password>\n\n*Contoh:*\n${m.prefix + m.command} 1gb alxzy pass123\n\n*Ukuran:*\n${Object.keys(RAM_OPTIONS).join(', ')}`);
        }

        const [size, name, password] = m.args;
        const selectedOption = RAM_OPTIONS[size.toLowerCase()];

        if (!selectedOption) {
          return m.reply(`❌ *Ukuran tidak valid!*\n\nPilih: ${Object.keys(RAM_OPTIONS).join(', ')}`);
        }
        
        await m.reply("⏳ Sedang memproses permintaan Anda, harap tunggu...");

        const serverDetails = await createPterodactylServer({
          name: name,
          password: password,
          ram: selectedOption.ram,
          disk: selectedOption.disk,
          cpuPercent: selectedOption.cpu,
          eggId: defaultEggId,
          locationId: defaultLocationId,
          admin: selectedOption?.admin? true : false
        });

        if (serverDetails) {
            const successMessage = `
✅ *Server Berhasil Dibuat!*

*Panel URL:* ${panelUrl}
*Username:* \`${serverDetails.username}\`
*Password:* \`${serverDetails.password}\`
*Server ID:* \`${serverDetails.serverIdentifier}\`

Silakan login untuk mengelola server Anda.`;
          await m.reply(successMessage);
        } else {
          await m.reply("❌ Gagal membuat server. Periksa konsol untuk detail atau hubungi administrator.");
        }

      } catch (error) {
        console.error('Error di command cpanel:', error);
        await m.reply('❌ Terjadi kesalahan internal saat memproses permintaan Anda.');
      }
      break;
    }
    
case "addprem": {
    if (!Ac) return m.reply("Kamu tidak ada akses");
    if (!m.text) return m.reply("Tag orang atau masukkan nomornya");

    let nomor = (m.text.includes("@") ? m.text.split("@")[0] : m.text).replace(/[^0-9]/g, "");
    if (!nomor) return m.reply("Nomor tidak valid");

    await ensurePremiumFile();
    let pm = JSON.parse(await fs.readFile(premiumFile, "utf-8"));

    if (pm.includes(nomor)) return m.reply(`Nomor ${nomor} sudah ada di daftar premium`);

    pm.push(nomor);
    await fs.writeFile(premiumFile, JSON.stringify(pm, null, 2));

    m.reply(`✅ Nomor ${nomor} berhasil ditambahkan ke daftar premium`);
    break;
}

case "delprem": {
    if (!Ac) return m.reply("Kamu tidak ada akses");
    if (!m.text) return m.reply("Tag orang atau masukkan nomornya");

    let nomor = (m.text.includes("@") ? m.text.split("@")[0] : m.text).replace(/[^0-9]/g, "");
    if (!nomor) return m.reply("Nomor tidak valid");

    await ensurePremiumFile();
    let pm = JSON.parse(await fs.readFile(premiumFile, "utf-8"));

    if (!pm.includes(nomor)) return m.reply(`Nomor ${nomor} tidak ada di daftar premium`);

    pm = pm.filter(u => u !== nomor);
    await fs.writeFile(premiumFile, JSON.stringify(pm, null, 2));

    m.reply(`🗑️ Nomor ${nomor} berhasil dihapus dari daftar premium`);
    break;
}

case "listprem": {
    await ensurePremiumFile();
    let pm = JSON.parse(await fs.readFile(premiumFile, "utf-8"));

    if (pm.length === 0) return m.reply("❌ Tidak ada pengguna premium");

    let list = "👑 *Daftar Premium*\n\n" + pm.map((u, i) => `${i + 1}. ${u}`).join("\n");
    list += `\n\nTotal: ${pm.length} pengguna`;

    m.reply(list);
    break;
}
default: 
   if (m.command === ">") {
     let te = `(async () => { ${m.args.join(" ")} })()`;
     try {
   let as = await eval(te);
   m.reply(util.format(as));
     } catch(error) {
       m.reply(util.format(error.message? error.message : error.messages || error))
     }
   }
  }
}
}

async function createPterodactylServer({ name, password, ram, disk, cpuPercent, eggId, locationId, admin }) {
  const safeUsername = name.toLowerCase().replace(/[^a-z0-9_.-]/g, '');
  const email = `${safeUsername}@${(new URL(panelUrl)).hostname}`;

  const user = await createUser({
    username: safeUsername,
    email,
    firstName: name,
    lastName: 'User',
    password,
    admin
  });
  if (!user) return null;

  const eggDetails = await getEggDetails(nestId, eggId);
  if (!eggDetails) {
      console.error(`❌ Gagal mendapatkan detail untuk Egg ID: ${eggId}`);
      return null;
  }
  
  const allocation = await findAvailableAllocation(locationId);
  if (!allocation) {
    console.error(`❌ Tidak ada alokasi (port) yang tersedia di Lokasi ID: ${locationId}.`);
    return null;
  }

  try {
    const serverPayload = {
      name: `${name}'s Server`,
      user: user.id,
      egg: eggId,
      docker_image: eggDetails.docker_image,
      startup: eggDetails.startup,
      environment: eggDetails.environment,
      limits: {
        memory: ram,
        swap: 0,
        disk: disk,
        io: 500,
        cpu: cpuPercent,
      },
      feature_limits: {
        databases: 1,
        allocations: 1,
        backups: 1,
      },
      allocation: {
        default: allocation.id,
      },
    };

    const { data: serverData } = await axios.post(`${panelUrl}/api/application/servers`, serverPayload, { headers });
    
    console.log('✅ Server berhasil dibuat:', serverData.attributes.identifier);
    
    return {
        username: safeUsername,
        password: password,
        serverIdentifier: serverData.attributes.identifier,
        panelUrl: panelUrl,
    };

  } catch (err) {
    console.error('❌ Gagal membuat server:', err.response?.data?.errors || err.message);
    return null;
  }
}

async function createUser({ username, email, firstName, lastName, password, admin}) {
  try {
    const { data } = await axios.post(`${panelUrl}/api/application/users`, {
      username: username,
      email: email,
      first_name: firstName,
      last_name: lastName,
      password: password,
      root_admin: admin,
    }, { headers });
    console.log(`✅ User berhasil dibuat: ${username} (ID: ${data.attributes.id})`);
    return data.attributes;
  } catch (err) {
    if (err.response?.data?.errors?.[0]?.code === 'UnprocessableEntityHttpException') {
        console.warn(`⚠️ User '${username}' atau email '${email}' sudah ada. Mencoba mencari user...`);
        return findUserByUsername(username);
    }
    console.error('❌ Gagal membuat user:', err.response?.data?.errors || err.message);
    return null;
  }
}

async function findUserByUsername(username) {
    try {
        const { data } = await axios.get(`${panelUrl}/api/application/users?filter[username]=${username}`, { headers });
        if (data.data.length > 0) {
            console.log(`✅ User '${username}' ditemukan.`);
            return data.data[0].attributes;
        }
        console.error(`❌ User '${username}' tidak ditemukan setelah gagal membuat.`);
        return null;
    } catch (err) {
        console.error(`❌ Gagal mencari user '${username}':`, err.message);
        return null;
    }
}

async function findAvailableAllocation(locationId) {
  try {
    const { data: nodes } = await axios.get(`${panelUrl}/api/application/nodes`, { headers });
    for (const node of nodes.data) {
      if (node.attributes.location_id === locationId) {
        const nodeId = node.attributes.id;
        const { data: allocations } = await axios.get(`${panelUrl}/api/application/nodes/${nodeId}/allocations`, { headers });
        const availableAllocation = allocations.data.find(alloc => !alloc.attributes.assigned);
        
        if (availableAllocation) {
          console.log(`✅ Alokasi tersedia ditemukan di Node ID ${nodeId}:`, availableAllocation.attributes.id);
          return availableAllocation.attributes; 
        }
      }
    }
    console.error(`❌ Tidak ada alokasi (port) tersedia yang ditemukan di Lokasi ID: ${locationId}`);
    return null;
    
  } catch(err) {
      console.error('❌ Gagal saat proses mencari alokasi:', err.response?.data?.errors || err.message);
      return null;
  }
}

async function getEggDetails(nestId, eggId) {
    try {
        const { data } = await axios.get(`${panelUrl}/api/application/nests/${nestId}/eggs/${eggId}?include=variables`, { headers });
        const attr = data.attributes;
        const environment = attr.relationships.variables.data.reduce((env, variable) => {
            env[variable.attributes.env_variable] = variable.attributes.default_value;
            return env;
        }, {});

        return {
            docker_image: attr.docker_image,
            startup: attr.startup,
            environment: environment,
        };
    } catch (err) {
        console.error('❌ Gagal mendapatkan detail Egg:', err.response?.data?.errors || err.message);
        return null;
    }
}