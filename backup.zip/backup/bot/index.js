import Pino from "pino";
import makeWASocket, {
 makeCacheableSignalKeyStore,
 useMultiFileAuthState,
 fetchLatestBaileysVersion,
 DisconnectReason,
 Browsers
} from 'baileys';
import chalk from "chalk";
import readline from 'readline';
import { Boom } from "@hapi/boom";
import fs from "fs";
import pino from "pino"
import { simple, protoType } from "./lib/s.js";
global.protoType = protoType
protoType()
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

const logger = pino({ timestamp: () => `,"time":"${new Date().toJSON()}"` }, pino.destination('./alxzy.log'))
logger.level = 'debug'
async function Create() {
  const { state, saveCreds } = await useMultiFileAuthState("./database/sessions")
  const { version } = await fetchLatestBaileysVersion()
const alxzy = simple({
  version,
  logger,
  auth: {
    creds: state.creds,
    keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: "silent", stream: "store" }))
  },
  browser: Browsers.ubuntu("Chrome"),
  shouldSyncHistoryMessage: (msg) => {
    console.log(`\x1b[32mMemuat Chat [${msg.progress}%]\x1b[39m`);
    return !!msg.syncType;
  },
  syncFullHistory: true,
  generateHighQualityLinkPreview: true
})
if (!alxzy.authState.creds.registered) {
  //console.clear();
  console.log(chalk.magenta("——————————————————"));
  const number = await question(chalk.blue("Input Whatsapp Number: "));
  const code = await alxzy.requestPairingCode(number.trim());
  console.log(chalk.green(`Your code: ${code}`));
  console.log(chalk.magenta("——————————————————"));
}
alxzy.ev.on("connection.update", async (update) => {
  const { connection, lastDisconnect, qr } = update;



  if (connection === "close") {
    const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;

    switch (reason) {
      case DisconnectReason.loggedOut:
        console.log("device logout, logout...");
        process.exit(1);
        break;
      case DisconnectReason.restartRequired:
      case DisconnectReason.timedOut:
      await Create()
        break;
    }
  } else if (connection === "open") {
    console.log("Berhasil tersambung, connected");
    }
})
alxzy.ev.on("creds.update", saveCreds)
alxzy.ev.on("messages.upsert", async (updates) => {
  let messages = updates.messages[0]
  if (!messages.message) return
  if (messages.key.id.startsWith("BAE5") || (messages.key.id.startsWith("3EB0") && messages.key.id.length === 22)) return
  let m = await alxzy.smsg(messages);
  await (await import("./alxzy.js")).default(m, alxzy)
})
}
Create()