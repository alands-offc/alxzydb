const {
  makeWASocket,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  Browsers,
  delay
} = require("baileys");
const pino = require("pino");
const fs = require("fs");
const readline = require("readline");
const { Boom } = require("@hapi/boom");
const chalk = require("chalk");
const store = require("./lib/store");
const { pesan, kirim } = require("./pesan.js");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

const logger = pino({ timestamp: () => `,"time":"${new Date().toJSON()}"` }, pino.destination("./zanspiw.log"));
logger.level = "debug";

async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState("./sessions");
  const { version, islatest } = await fetchLatestBaileysVersion();
  console.log(`Versi Baileys: ${version.join(".")}, terbaru: ${islatest}`);

  let zanspiw = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: "silent", stream: "store" })),
    },
    browser: Browsers.ubuntu("Chrome"),
    shouldSyncHistoryMessage: () => true,
    syncFullHistory: true,
    generateHighQualityLinkPreview: true,
  });
  if (!zanspiw.authState.creds.registered) {
    console.log(chalk.magenta("——————————————————"));
    const number = await question(chalk.blue("Input Whatsapp Number: "));
    const code = await zanspiw.requestPairingCode(number.trim());
    console.log(chalk.green(`Your code: ${code}`));
    console.log(chalk.magenta("——————————————————"));
  }
  zanspiw = await kirim(zanspiw)
  // Event handler
  zanspiw.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
      if (connection === "close") {
    const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;

    switch (reason) {
      case DisconnectReason.loggedOut:
        console.log("device logout, logout...");
        process.exit(1);
        break;
      case DisconnectReason.restartRequired:
      case DisconnectReason.timedOut:
      await connect()
        break;
    }
  } else if (connection === "open") {
    store.bind(zanspiw);
    console.log("Berhasil tersambung, connected");
    }
  });

  zanspiw.ev.on("creds.update", saveCreds);

  zanspiw.ev.on("messages.upsert", async (updates) => {
    let messages = updates.messages[0];
    if (!messages.message) return;
    if (messages.key.id.startsWith("BAE5") || (messages.key.id.startsWith("3EB0") && messages.key.id.length === 22)) {
      return;
    }

    const m = await pesan(zanspiw, messages);
    await require("./lib/log.js")(zanspiw, m);
    await require("./zanspiw.js")(zanspiw, m);
    await delay(3000)
  });
}

connect();