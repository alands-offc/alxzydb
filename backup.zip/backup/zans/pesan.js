const createConfig = require("./config")
const {
  areJidsSameUser,
  Browsers,
  delay,
  downloadContentFromMessage,
  downloadMediaMessage,
  extractMessageContent,
  fetchLatestWaWebVersion,
  generateForwardMessageContent,
  generateWAMessage,
  generateWAMessageContent,
  generateWAMessageFromContent,
  getAggregateVotesInPollMessage,
  getContentType,
  jidDecode,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  generateMessageTag,
  relayWAMessage,
  InteractiveMessage,
  proto,
} = require("baileys");
const { format } = require("util");
const PhoneNumber = require("awesome-phonenumber");
const pino = require("pino");

const decodeJid = function(jid) {
  if (/:\d+@/gi.test(jid)) {
    const decode = jidDecode(jid) || {};
    return (decode.user && decode.server && `${decode.user}@${decode.server}` || jid).trim();
  } else {
    return jid.trim();
  }
};

async function kirim(zanspiw) {
  zanspiw.decodeJid = (jid) => {
    if (!jid || typeof jid !== "string") return jid || null;
    return decodeJid(jid);
  };
  zanspiw.getName = (jid = "", withoutContact = false) => {
    jid = zanspiw.decodeJid(jid);
    if (!jid || typeof jid !== "string") return "";

    withoutContact = zanspiw.withoutContact || withoutContact;
    let v;

    if (jid.endsWith("@g.us")) {
      return new Promise(async (resolve) => {
        v = zanspiw.chats[jid] || {};
        if (!(v.name || v.subject)) {
          try {
            v = await zanspiw.groupMetadata(jid);
          } catch (e) {
            v = {};
          }
        }
        resolve(
          v.name ||
          v.subject ||
          PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber("international")
        );
      });
    }

    v = jid === "0@s.whatsapp.net" ?
      { jid, vname: "WhatsApp" } :
      areJidsSameUser(jid, zanspiw.user.id) ?
      zanspiw.user :
      (zanspiw.chats[jid] || {});

    return (
      (withoutContact ? "" : v.name) ||
      v.subject ||
      v.vname ||
      v.notify ||
      v.verifiedName ||
      PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber("international")
    );
  };
  zanspiw.download = async(message) => {
    return await downloadMediaMessage(message, "buffer", {}, {
      logger: pino({ level: "silent" }),
      reuploadRequest: zanspiw.updateMediaMessage,
    });
  };
  return zanspiw
}

async function pesan(zanspiw, m) {
  let config = await createConfig();
  if (!m) return false;

  const getText = (message) => {
    if (!message) return "";
    try {
      return (
        message.text ||
        message.conversation ||
        message.caption ||
        message.selectedButtonId ||
        message.singleSelectReply?.selectedRowId ||
        message.selectedId ||
        message.contentText ||
        message.selectedDisplayText ||
        message.title ||
        message.name ||
        (message.nativeFlowResponseMessage ? JSON.parse(message.nativeFlowResponseMessage.paramsJson)?.id : "")
      );
    } catch (e) {
      console.error(e);
      return "";
    }
  };

  const parseMessage = (content) => {
    content = extractMessageContent(content);
    if (content?.viewOnceMessageV2Extension) content = content.viewOnceMessageV2Extension.message;
    if (content?.ephemeralMessage) content = content.ephemeralMessage.message;
    if (content?.protocolMessage?.type === 14) {
      const type = getContentType(content.protocolMessage);
      content = content.protocolMessage[type];
    }
    if (content?.message) {
      const type = getContentType(content.message);
      content = content.message[type];
    }
    return content;
  };

  const escapeRegExp = (str) => {
    return str.replace(/[.*=+:\-?^${}()|[\]\\]|\s/g, "\\$&");
  };

  m.id = m.key.id;
  m.chat = m.key.remoteJid;
  m.fromMe = m.key.fromMe;
  m.sender = m.fromMe ?
    jidNormalizedUser(zanspiw.user.id) :
    m.chat.includes("@s.whatsapp.net") ?
    m.chat :
    m.key.participant;
  m.name = zanspiw.getName(m.sender) || m.pushName;

  if (m.message) {
    m.message = parseMessage(m.message);
    m.type = Object.keys(m.message).find(
        (a) => a.includes("conver") ||
        (!a.includes("senderKeyDistributionMessage") && a.endsWith("Message")) ||
        a.includes("V3")
      ) || Object.keys(m.message)[0] || "";

    m.msg = m.message.interactiveResponseMessage ? m.message : m.message[m.type];
    m.bot = m.id.startsWith("BAE5") || (m.id.startsWith("3EB0") && m.id.length === 22);
    m.group = m.chat.endsWith("@g.us");
    m.expiration = m.msg?.contextInfo?.expiration || 0;
    m.viewOnce = !!m.msg?.viewOnce;

    if (m.group) {
      m.metadata = await zanspiw.groupMetadata(m.chat);
      m.gcname = m.metadata.subject;
      m.participants = m.metadata.participants;
      m.isGroupOwner = m.metadata.owner;
      m.admin = m.participants.filter(a => a.admin === "admin" || a.admin === "superadmin").map(a => a.id);
      m.isAdmin = m.admin.includes(m.sender);
      m.isBotAdmin = m.admin.includes(jidNormalizedUser(zanspiw.user?.id));
    }

    m.text = getText(m.msg) || m.message?.conversation;
    m.prefix = new RegExp(`^[${config.bot.prefix.join("")}^]`, "gi").test(m.text) ?
      m.text.match(new RegExp(`^[°•π÷×¶∆£¢€¥®™+✓=|/~!?@#%^&.©^]`, "gi"))?.[0] :
      "";
    m.command = m.text?.trim().replace(m.prefix, "").trim().split(/ +/).shift();
    m.args = m.text?.trim()
      .replace(new RegExp("^" + escapeRegExp(m.prefix), "i"), "")
      .replace(m.command, "")
      .split(/ +/)
      .filter((a) => a) || [];
    m.mentionedJid = m.msg.contextInfo?.mentionedJid || [];
    m.download = async() => await zanspiw.download(m);

    if (m.msg?.contextInfo?.quotedMessage) {
      const quoted = m.msg.contextInfo;
      m.quoted = {
        key: {
          remoteJid: m.chat,
          id: quoted?.stanzaId,
          fromMe: quoted?.participant.includes(jidNormalizedUser(zanspiw.user?.id)),
          participant: quoted.participant,
        },
        chat: m.chat,
        sender: quoted.participant.includes(jidNormalizedUser(zanspiw.user?.id)) ?
          jidNormalizedUser(zanspiw.user.id) :
          quoted.participant || m.chat,
        id: quoted?.stanzaId,
        fromMe: quoted.participant.includes(jidNormalizedUser(zanspiw.user?.id)),
        message: parseMessage(quoted?.quotedMessage),
      };

      const qmsg = m.quoted.message;
      m.quoted.type = Object.keys(qmsg).find(
        (a) => a.includes("conver") || a.endsWith("Message") || a.includes("V3")
      );
      m.quoted.msg = qmsg[m.quoted.type];
      m.quoted.mentionedJid = quoted?.mentionedJid || [];
      m.quoted.group = m.quoted.chat.endsWith("@g.us");
      m.quoted.viewOnce = !!m.quoted.msg?.viewOnce;
      m.quoted.bot = m.quoted?.id?.includes("BAE5") || m.quoted?.id.startsWith("3EB0");
      m.quoted.text = getText(m.quoted.msg) || m.quoted.message.conversation;

      m.quoted.prefix = new RegExp(`^[${config.bot.prefix.join("")}^]`, "gi").test(m.quoted.text) ?
        m.quoted.text.match(new RegExp(`^[°•π÷×¶∆£¢€¥®™+✓=|/~!?@#%^&.©^]`, "gi"))?.[0] :
        "";
      m.quoted.command = m.quoted.text?.trim().replace(m.quoted.prefix, "").trim().split(/ +/).shift();
      m.quoted.args = m.quoted.text?.trim()
        .replace(new RegExp("^" + escapeRegExp(m.quoted.prefix), "i"), "")
        .replace(m.quoted.command, "")
        .split(/ +/)
        .filter((a) => a) || [];
      m.quoted.download = async() => await zanspiw.download(m.quoted);
    }

    m.reply = async(text, options = {}) => {
      const msgPayload = typeof text === "string" ? { text, ...options } : { ...text, ...options };
      return await zanspiw.sendMessage(m.chat, msgPayload, {
        quoted: m,
        ephemeralExpiration: m.expiration,
        ...options,
      });
    };

    m.wait = async() => await m.reply("bentar");
  }

  return m;
}
module.exports = { pesan, kirim }