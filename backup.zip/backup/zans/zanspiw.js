const axios = require("axios")
module.exports = async function (zanspiw, m) {
  let args = m.args;
 let text = m.args.join(" ");
 let sender = m.sender 
 if (m.command && m.prefix) {
   switch(m.command.toLowerCase()) {
     case "biji": {
       m.reply("biji");
     }
     break
   } //penutup switch
 } //penutup if (m.command && m.prefix)
 return //stop 
} //penutup