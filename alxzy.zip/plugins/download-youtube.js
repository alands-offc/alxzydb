import fetch from "node-fetch";

let handler = async (m, { conn, text }) => {
  if (!text) throw "Masukkan judul atau URL video YouTube dengan format:\n.youtube judul/video|audio/video";

  let [input, format] = text.split("|").map(s => s.trim());
  format = format?.toLowerCase() === "audio" ? "audio" : "video";

  let isUrl = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i.test(input);
  let videoUrl = input;

  if (!isUrl) {
    let search = await fetch(`${alxzy}youtube-search?text=${encodeURIComponent(input)}`);
    let searchResult = await search.json();

    if (!searchResult?.results?.all?.length) throw "Video tidak ditemukan.";
    videoUrl = searchResult.results.all[0].url;
  }

  let quality = format === "audio" ? "128kbps" : "480p";

  let res = await fetch(`${alxzy}youtube-download?url=${encodeURIComponent(videoUrl)}&quality=${quality}`);
  let data = await res.json();

  if (!data?.results?.download) throw "Gagal mengambil video/audio.";

  let title = data.results.title || "youtube";
  let thumb = data.results.thumbnail || "";
  let source = data.results.url || "";

  let fileName = `akaza-md-${title.replace(/[^\w\s]/gi, '')}.${format === "audio" ? "mp3" : "mp4"}`;
  let message = format === "audio"
    ? {
        audio: { url: data.results.download },
        mimetype: "audio/mpeg",
        fileName,
      }
    : {
        video: { url: data.results.download },
        mimetype: "video/mp4",
        fileName,
      };

  message.contextInfo = {
    mentionedJid: [m.sender],
    externalAdReply: {
      title: title,
      body: "Downloader YouTube",
      thumbnailUrl: thumb,
      renderLargerThumbnail: true,
      mediaType: 1,
      sourceUrl: source,
    }
  };

  await conn.sendMessage(m.chat, message, { quoted: m });
};

handler.command = ["youtube"]
handler.help = ["youtube text/url|audio/video"]
handler.limit = 2
export default handler;
