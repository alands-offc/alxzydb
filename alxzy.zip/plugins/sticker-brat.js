import fetch from "node-fetch"; 
let handler = async (m, { conn, text, command }) => {
  if (command === "brat") {
  if (!text) throw "contoh .brat oi"
  let api = `https://www.apis-anomaki.zone.id/tools/sticker-brat?text=${encodeURIComponent(text)}`
  let data = await (await fetch(api)).json()
  let media = await (await fetch(data.result.url)).buffer()
  let stiker = await sticker.imageToSticker(media)
 try {
   await conn.sendMessage(m.chat, {
     sticker: stiker,
     fileName: "Akaza-md sticker.webp",
     mimeType: "image/webp"
   }, { quoted: m })
 } catch (e) {
   throw e.message
 }
} else if (command === "bratvid") {
  if (!text) throw "contoh .bratvid oi oi";
  let api = `https://fastrestapis.fasturl.cloud/maker/brat/animated?text=${encodeURIComponent(text)}&mode=animated`;
  let data = await (await fetch(api)).buffer();
  let stiker = await sticker.videoToSticker(data);
  try {
    await conn.sendMessage(m.chat, {
      sticker: stiker, 
      fileName: "akaza - md animated.webp",
      mimeType: "video/webp",
    }, { quoted: m })
  } catch (error) {
    throw e.message
  }
} 
}
handler.help = ["brat <text>", "bratvid <text>"]
handler.command = ["brat", "bratvid"]
handler.limit = 3 
export default handler