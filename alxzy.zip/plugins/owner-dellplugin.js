import fs from "fs";
import path from "path";
import util from "util";
import { execSync } from "child_process";

let handler = async (m, { conn, text }) => {
  const filename = text.trim();

  if (!filename) {
    try {
      const list = execSync("ls plugins").toString();
      return m.reply(`📁 Isi folder *plugins*:\n\n${list}`);
    } catch (e) {
      conn.logger.error(e);
      return m.reply("❌ Gagal membaca folder plugins.");
    }
  }

  if (!(filename.endsWith(".js") || filename.endsWith(".mjs"))) {
    return m.reply("❌ Masukkan nama file dengan ekstensi .js atau .mjs");
  }

  const filePath = path.join("plugins", filename);

  if (!fs.existsSync(filePath)) {
    return m.reply(`❌ File *${filename}* tidak ditemukan di folder plugins.`);
  }

  try {
    fs.unlinkSync(filePath);
    return m.reply(`✅ File *${filename}* berhasil dihapus.`);
  } catch (error) {
    conn.logger.error(error);
    return m.reply("❌ Gagal menghapus file.");
  }
};

handler.command = ["dellplugin"];
handler.owner = true;
handler.tags = ["owner"];
handler.help = ["dellplugin <fileName>"];

export default handler;
