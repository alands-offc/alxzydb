import fetch from 'node-fetch'

const XP_PER_LEVEL = 100 // bisa dikali multiplier kalau mau

export const all = async (m, { conn }) => {
  if (!m.sender) return;

  let user = global.db.data.users[m.sender];
  if (!user || !user.autolevelup) return;

  const multiplier = global.multiplier || 1;
  const need = XP_PER_LEVEL * multiplier;

  let username = m.name;
  let beforeLevel = user.level;
  let exp = user.exp;
  let leveledUp = false;

  while (user.exp >= need) {
    user.level += 1;
    user.exp -= need;
    leveledUp = true;
  }

  if (leveledUp) {
    const newRole = getRoleByLevel(user.level);
    const oldRole = user.role;
    user.role = newRole;

    let logo;
    try {
      logo = await (await fetch(global.thumbnail || 'https://telegra.ph/file/4cc124a5e6eb1fbb9981e.jpg')).buffer();
    } catch (e) {
      console.error("Gagal ambil gambar level up:", e);
    }

    const tag = `@${m.sender.replace(/@.+/, '')}`;
    const levelUpMsg = `
✨ *LEVEL UP!* ✨
────────────────────
👤 *Name:* ${tag}
⚡ *Exp:* ${exp}
🎯 *Level:* ${beforeLevel} ➜ ${user.level}
🏷️ *Role:* ${oldRole} ➜ ${newRole}
────────────────────
Terus semangat dan tetap aktif ya! 💪🔥
`.trim();

    await conn.sendMessage(m.chat, {
      image: logo,
      caption: levelUpMsg,
      contextInfo: {
        mentionedJid: [m.sender]
      }
    }, { quoted: m });
  }
};

function getRoleByLevel(level) {
  if (level >= 100) return '👑 Immortal';
  if (level >= 90) return '🛡 Mythic';
  if (level >= 80) return '🎖 Legend';
  if (level >= 70) return '⚔ Grandmaster';
  if (level >= 60) return '🔥 Master';
  if (level >= 50) return '💎 Diamond';
  if (level >= 40) return '🔷 Platinum';
  if (level >= 30) return '🥇 Gold';
  if (level >= 20) return '🥈 Elite';
  if (level >= 10) return '🥉 Bronze';
  return '🧱 Beginner';
}
